package com.example.slide_action

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
